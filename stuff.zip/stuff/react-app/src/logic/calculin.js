const calculin = {
    sum(a, b) { return a + b },

    sub(a, b) { return a - b },

    mul(a, b) { return a * b },

    div(a, b) { return a / b }
}

export default calculin