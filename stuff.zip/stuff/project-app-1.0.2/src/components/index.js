import Register from './register'
import Login from './login'
import Home from './home'
import Landing from './landing'

export {
    Register,
    Login,
    Home,
    Landing
}