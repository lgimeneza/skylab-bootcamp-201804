[VSC key bindings](https://code.visualstudio.com/docs/getstarted/keybindings)

[VS Code Extensions for Happier JavaScript Coding](https://hackernoon.com/vs-code-extensions-for-happier-javascript-coding-e258f72dd9c1)
