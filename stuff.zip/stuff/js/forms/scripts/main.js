document.getElementById('my-form').addEventListener('submit', function(event) {
    event.preventDefault();

    console.log(document.getElementById('something').value)
})