'use strict'

function Title(props) {
    return <h1>{ props.text }</h1>
}