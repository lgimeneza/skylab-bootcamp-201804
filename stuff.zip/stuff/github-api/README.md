[Github API](https://api.github.com/users)

- [search users](https://developer.github.com/v3/search/#search-users)

demo: https://api.github.com/search/users?q=tom

- [get a single user](https://developer.github.com/v3/users/#get-a-single-user)

demo: https://api.github.com/users/manuelbarzi

[Personal access tokens](https://github.com/settings/tokens)