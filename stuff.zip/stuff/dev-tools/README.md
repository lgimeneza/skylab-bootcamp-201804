[Run copy(obj) in the Console to copy an object to your clipboard](https://twitter.com/ChromeDevTools/status/974280084113772544?s=09)

[Get Started with Debugging JavaScript in Chrome DevTools](https://developers.google.com/web/tools/chrome-devtools/javascript/)