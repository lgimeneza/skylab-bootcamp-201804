# References

[Programming, Scripting, and Markup Languages](https://insights.stackoverflow.com/survey/2018/?utm_source=Iterable&utm_medium=email&utm_campaign=dev-survey-2018-promotion#technology-programming-scripting-and-markup-languages)