var $h1 = $('h1');

$h1.text('Hello, World!');

var h1 = $h1.text();

console.log(h1);