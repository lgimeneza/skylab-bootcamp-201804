[Introduction to jQuery](https://www.codecademy.com/learn/learn-jquery)
