# References

[Semantic HTML](https://internetingishard.com/html-and-css/semantic-html/)

[A look into proper HTML5 semantics](https://www.hongkiat.com/blog/html-5-semantics/)

[How to properly use the HTML semantic elements in a blog?](https://stackoverflow.com/questions/44987392/how-to-properly-use-the-html-semantic-elements-in-a-blog)

[HTML5 semantic elements and Webflow: the essential guide](https://webflow.com/blog/html5-semantic-elements-and-webflow-the-essential-guide)

[Anatomía de un blog en HTML5](https://cybmeta.com/anatomia-de-un-blog-en-html5)

[Designing a blog with html5](http://html5doctor.com/designing-a-blog-with-html5/)

[HTML is about meaning](https://marksheet.io/html-semantics.html)

