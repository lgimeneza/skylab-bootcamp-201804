// install node version 10, and then do:
// $ node --experimental-modules index.mjs

//const sum = require('./sum')
import sum from './sum'

console.log(sum(1,2,3,4,5,6))