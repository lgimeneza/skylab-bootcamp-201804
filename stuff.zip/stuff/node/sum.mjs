function sum(...nums) {
    return nums.reduce((accum, v) => accum + v)
}

//module.exports = sum
export default sum