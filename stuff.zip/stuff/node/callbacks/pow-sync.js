function powSync(a, b) {
    return a ** b
}

console.log(powSync(powSync(powSync(2, 2), 3), 4))