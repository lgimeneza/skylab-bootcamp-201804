[Jasmine specs generating different random numbers than on execution](https://stackoverflow.com/questions/15753107/jasmine-specs-generating-different-random-numbers-than-on-execution)
