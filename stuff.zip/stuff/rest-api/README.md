[Conceptos sobre APIs REST](http://asiermarques.com/2013/conceptos-sobre-apis-rest/)

[public apis](https://github.com/toddmotto/public-apis)