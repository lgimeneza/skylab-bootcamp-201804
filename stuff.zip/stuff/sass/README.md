# Sass lang

```sh
$ sass main.scss main.css
```

to watch changes and transform automatically

```sh
$ sass --watch main.scss:main.css
```