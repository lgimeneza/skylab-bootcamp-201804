'use strict'

const { mongoose, models: { User, Service, Booking } } = require('data')

// TODO