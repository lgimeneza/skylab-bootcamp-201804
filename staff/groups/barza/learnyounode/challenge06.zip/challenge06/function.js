const fs = require('fs');
const path = require('path');

module.exports = function filterFiles(directory, extension, callback) {
    fs.readdir(directory, (err, files) => {
        if (err) return callback(err);

        files.forEach(file => {
            const ext = path.extname(file); //extname te proporciona la extensión con el punto '.txt'

            if (ext === '.' + extension) {
                return callback(null, file);
            }
        });
    });
};
