
document.getElementById("myForm").addEventListener("submit", function(event){
    //anul·lar comportament de l'event assignat
    event.preventDefault();

    console.log("funciona")
})